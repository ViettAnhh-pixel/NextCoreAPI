﻿// See https://aka.ms/new-console-template for more information
using NewApp.Models;

public class Progam{
    private static  void Main(string[] args)
    {
       /* Person ps1 = new Person();
        Person ps2 = new Person();
        ps1.FullName = "Nguyen Van A";
        ps1.Address = "Hanoi";
        ps1.Age = 17;
        ps1.Display();
        ps2.Display();
        Person ps = new Person();
        string str = "Nguyen Van B";
        int a = 22;
        ps.Display2(str, a);
        Console.WriteLine("{0} sinh nam {1}",str,ps.GetYearOfBirth(a));*/

        /*Employee em = new Employee();
        em.id =001;
        em.name = "Ngo H";
        em.age = 25;
        em.salary = 250000;
        em.DisplayEmployee();*/

       /*Student st = new Student();
        st.MSSV = 2121050112;
        st.name = "Nguyen Quoc Anh";
        st.age = 22;
        st.lop = "DCCTCT66_04C";
        st.DisplayStudent();*/
        
        Fruit ft = new Fruit();
        ft.name = "Mit";
        ft.NSX = "Nhat";
        ft.namSX = 2025;
        ft.DisplayFruit();

    }
}

